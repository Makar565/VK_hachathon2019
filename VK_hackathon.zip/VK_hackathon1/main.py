import vk_api, random
import moi_base as vb
vk_session = vk_api.VkApi(token = 'ab79a3eebf43fe5f81a5305d2056d1500e0443939516feb1b31f42dce96f74fec9fa6fac51914214f6763')

from vk_api.longpoll import VkLongPoll, VkEventType

longpoll = VkLongPoll(vk_session)

vk = vk_session.get_api()

my_id = 103495898
mainText = ''

global Random

def random_id():
    Random = 0
    Random += random.randint(0, 100000000)
    return Random

while True:
    for event in longpoll.listen():
        if event.type == VkEventType.MESSAGE_NEW and event.to_me:
            mas1=[int(i) for i in vk.groups.getMembers(
                    group_id = '186293891',
                    count = 1000)['items']]
            
            if event.user_id  == my_id:
                mainText = event.text
                
            if mainText!='':
                vk_session = vk_api.VkApi(token = '32dd953f1dc8c748df7ee7be8d03ed0468da34477b9c6cddbea67532c5a35290a5a162c918a1a34384214')
                vk = vk_session.get_api()
                print(vk.wall.post(owner_id=-186293891 ,message=mainText))
                for h in mas1:
                    vk_session = vk_api.VkApi(token = '32dd953f1dc8c748df7ee7be8d03ed0468da34477b9c6cddbea67532c5a35290a5a162c918a1a34384214')
                    vk = vk_session.get_api()
                    dt=vk.users.get(user_ids=str(h),fields='bdate')[0]['bdate']
                    mas=[int(i) for i in dt.split('.')]
                    try:
                        year= 2019-mas[2]
                        if year<30:
                            text=vb.start(mainText,True)
                        else:
                            text=vb.start(mainText,False)
                        vk_session = vk_api.VkApi(token = 'ab79a3eebf43fe5f81a5305d2056d1500e0443939516feb1b31f42dce96f74fec9fa6fac51914214f6763')
                        vk = vk_session.get_api()
                        mas=[]
                    except IndexError:
                        print("Error")
                        vk_session = vk_api.VkApi(token = 'ab79a3eebf43fe5f81a5305d2056d1500e0443939516feb1b31f42dce96f74fec9fa6fac51914214f6763')
                        vk = vk_session.get_api()
                    try :
                        vk.messages.send(
                    user_id = h,
                    message = text,
                    random_id = random_id()
                    )
                    except vk_api.exceptions.ApiError:
                        print("ошибка")
                
                
