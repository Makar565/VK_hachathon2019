import pymorphy2
morph = pymorphy2.MorphAnalyzer()
ar={"телефон":"смартфон",'машина':'автомашина','смех':'рофл','смеяться':'рофлить'}
st=input()
slovo1=morph.parse(st)[0]
tag=slovo1.tag
print(tag)
sinonim=ar[slovo1.normal_form]
slovo2=morph.parse(sinonim)[0]

lexeme=slovo2.lexeme
for i in range(len(lexeme)):
	if lexeme[i].tag==tag:
		print(lexeme[i].word)


