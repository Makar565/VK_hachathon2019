import pandas as pd
import http.client
import lxml.html
url="https://text.ru/synonym/машина"

c = http.client.HTTPSConnection(url)
c.request("POST", "synonym/машина")
response = c.getresponse()
data = response.read()
#markup = lxml.html.fromstring(response)

print(
    lxml.html.tostring(
        data,
        encoding='unicode'
    )
)

