import vk_api, random
import moi_base as vb
vk_session = vk_api.VkApi(token = '71016ee5ed85d40fb5a9a6c2b3efed44ac76163ba35b16ea4de08d73918e446a3071b1b4a843b82eda90f')

from vk_api.longpoll import VkLongPoll, VkEventType

longpoll = VkLongPoll(vk_session)

vk = vk_session.get_api()

my_id = 103495898
mainText = ''

global Random

def random_id():
    Random = 0
    Random += random.randint(0, 100000000)
    return Random

while True:
    for event in longpoll.listen():
        if event.type == VkEventType.MESSAGE_NEW and event.to_me:
            mas1=[int(i) for i in vk.groups.getMembers(
                    group_id = '186308095',
                    count = 1000)['items']]
            
            if event.user_id  == my_id:
                mainText = event.text
                
            if mainText!='':
                vk_session = vk_api.VkApi(token = '4463881d628025c4903eb0ffc6896aeeb95b675e27cd98458af86c6070c76a7c73e3dd44ac75752ceca2f')
                vk = vk_session.get_api()
                print(vk.wall.post(owner_id=-186308095 ,message=mainText))
                for h in mas1:
                    vk_session = vk_api.VkApi(token = '4463881d628025c4903eb0ffc6896aeeb95b675e27cd98458af86c6070c76a7c73e3dd44ac75752ceca2f')
                    vk = vk_session.get_api()
                    dt=vk.users.get(user_ids=str(h),fields='bdate')[0]['bdate']
                    mas=[int(i) for i in dt.split('.')]
                    try:
                        year= 2019-mas[2]
                        if year<30:
                            text=vb.start(mainText,True)
                        else:
                            text=vb.start(mainText,False)
                        vk_session = vk_api.VkApi(token = '71016ee5ed85d40fb5a9a6c2b3efed44ac76163ba35b16ea4de08d73918e446a3071b1b4a843b82eda90f')
                        vk = vk_session.get_api()
                        mas=[]
                    except IndexError:
                        print("Error")
                        vk_session = vk_api.VkApi(token = '71016ee5ed85d40fb5a9a6c2b3efed44ac76163ba35b16ea4de08d73918e446a3071b1b4a843b82eda90f')
                        vk = vk_session.get_api()
                    try :
                        vk.messages.send(
                    user_id = h,
                    message = text,
                    random_id = random_id()
                    )
                    except vk_api.exceptions.ApiError:
                        print("ошибка")
                
                
