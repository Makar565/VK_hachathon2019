# -*- coding: utf-8 -*-
import time
import vk_api
#61424bdd301b65f2b560187319ff33c52e26f77158fd4aff9219a8d68e651fd9d2bd5a0897508dc921773
vk = vk_api.VkApi(token = '61424bdd301b65f2b560187319ff33c52e26f77158fd4aff9219a8d68e651fd9d2bd5a0897508dc921773')
#vk_api.VkApi(token = 'a02d...e83fd') #Авторизоваться как сообщество
vk.auth()
values = {'out': 0,'count': 100,'time_offset': 60}
vk.wall.post(message="HI")
def write_msg(user_id, s):
    vk.method('messages.send', {'user_id':user_id,'message':s})

while True:
    response = vk.method('messages.get', values)
    if response['items']:
        values['last_message_id'] = response['items'][0]['id']
    for item in response['items']:
            write_msg(item[u'user_id'],u'Привет, Хабр!')
    time.sleep(1)
