from sqlalchemy import create_engine
from sqlalchemy import MetaData
from sqlalchemy import Table
from sqlalchemy import Column
from sqlalchemy import Integer
from sqlalchemy import String,Date,DateTime

import pymorphy2
morph = pymorphy2.MorphAnalyzer()
#///////////////////////////
db_uri1 = "sqlite:///black.db3"
engine1 = create_engine(db_uri1)
#///////////////////////////
db_uri = "sqlite:///white.db3"
engine = create_engine(db_uri)

db_uri2 = "sqlite:///BD1.db3"
engine2 = create_engine(db_uri2)
#syn word
#text=input()
def ret_tag(slovo):
	slovo1=morph.parse(slovo)[0]
	tag=slovo1.tag
	return tag
def norm_form(slovo):
	
	slovo1=morph.parse(slovo)[0]
	norm_slovo=slovo1.normal_form
	return norm_slovo
	'''sinonim=ar[slovo1.normal_form]
	slovo2=morph.parse(sinonim)[0]
	lexeme=slovo2.lexeme
	for i in range(len(lexeme)):
		if lexeme[i].tag==tag:
			return(lexeme[i].word)'''
def search2(slovo):
	i=0
	for row in engine1.execute('select * from word where id <= 167748'):
		if dict(row)['text']==slovo:
			i=dict(row)['id']
			
	for row in engine1.execute('select * from syn where id <= 473347'):
		if i==0:
			return('1')
			
		if int(dict(row)['parent'])==i:
			return(dict(row)['text'])
			
def search(slovo):
	i=0
	for row in engine.execute('select * from word where id <= 48268'):
		if dict(row)['text']==slovo:
			i=dict(row)['id']
			
	for row in engine.execute('select * from syn where id <= 50395'):
		if i==0:
			return search2(slovo)
			
		if int(dict(row)['parent'])==i:
			return(dict(row)['text'])
			
def search_bd(slovo):
	i=0
	for row in engine2.execute('select * from word where id <= 7'):
		if dict(row)['text']==slovo:
			i=dict(row)['id']
			
	for row in engine2.execute('select * from syn where id <= 11'):
		if i==0:
			return slovo
			
		if int(dict(row)['parent'])==i:
			return(dict(row)['text'])	
#meta = MetaData(engine)
def start(text,bl):
        new_text=''
        if bl==False:
                for i in text.split():
                        tag=ret_tag(i)
                        nf=norm_form(i)
                        sd=search(i)
                        if sd=="None" or sd==None:
                                new_text+=i
                        elif sd!='1':
                                slovo2=morph.parse(sd)[0]
                                lexeme=slovo2.lexeme
                                for j in range(len(lexeme)):
                                        if lexeme[j].tag==tag:
                                                sd=lexeme[j].word
                                new_text+=sd
                        else:
                                new_text+=i
                        new_text+=' '
        else:
                for i in text.split():
                        tag=ret_tag(i)
                        nf=norm_form(i)
                        sd=search_bd(i)
                        if sd=="None" or sd==None:
                                new_text+=i
                        elif sd!='1':
                                slovo2=morph.parse(sd)[0]
                                lexeme=slovo2.lexeme
                                for j in range(len(lexeme)):
                                        if lexeme[j].tag==tag:
                                                sd=lexeme[j].word
                                new_text+=sd
                        else:
                                new_text+=i
                        new_text+=' '
        return new_text

