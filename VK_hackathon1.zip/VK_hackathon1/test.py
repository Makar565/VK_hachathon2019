import xappy
 
# открытие соединения для поиска с базой поискового индекса
# указывается полный или относительный путь к папке
connection = xappy.SearchConnection('/path/to/base')
connection.reopen()
# обычный поисковый запрос
query = connection.query_parse('день')

# нужны лишь первые 10 результатов
# для следующей десятки нужно указать 10, 20 и т.д.
results = connection.search(query, 0, 10)

# что-то нашлось
if results.matches_estimated > 0:
    for results_item in results:
        print(results_item.rank, results_item.id)
else:
    print('Ничего не найдено')

